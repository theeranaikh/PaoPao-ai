"""PaoPao command-line interface."""

